# 用matlab绘制各种数据图表
import scienceplots
import numpy as np
from matplotlib import pyplot as plt
from matplotlib import rcParams, gridspec
from typing import List
from pandas import DataFrame, Series
from typing import Union, Optional
import utils.plot.plot_params as params
# from subprocess import call

rcParams['font.family'] = params.font
rcParams['savefig.dpi'] = params.dpi
rcParams['figure.dpi'] = 0.4 * params.dpi
rcParams['savefig.format'] = params.pic_format
rcParams['savefig.bbox'] = 'tight'
plt.rcParams['axes.prop_cycle'] = plt.cycler(color=params.color)
plt.style.use(params.style)
# call(["epstool", "--add-missing-fonts", "--output", "example_with_fonts.eps", "example.eps"])
# call(["ps2pdf", "example_with_fonts.eps", "example_with_fonts.pdf"])

def plot_metrics(data: DataFrame,
                 nline: int,
                 width: Optional[str] = "Double column (full width)",
                 height: Optional[Union[int, float]] = 2,
                 metrics: Optional[List[str]] = None,
                 models: Optional[List[str]] = None,
                 save_path: Optional[str] = None,
                 ) -> None:
    """
    绘制多个模型的在多个指标上的表现。每个metric对应一张图，图中有len(models)条线。每张图的横坐标是columns

    :param data: 用于绘制的数据，包含一个MultiIndex，第一层是指标名称，第二层是模型名称, columns是时间
    :param nline: subplot的列数
    :param width: 选择绘制的图表的宽度，默认为"Double column (full width)"，可选值为"Minimal width", "Single column", "1.5 column", "Double column (full width)"
    :param height: 选择绘制的图表的高度，默认为2，单位为inch
    :param metrics: 选择绘制的指标，默认为None，表示绘制所有指标
    :param models: 选择绘制的模型，默认为None，表示绘制所有模型
    """
    # 检查数据
    all_metrics = data.index.get_level_values(0).unique()
    all_models = data.index.get_level_values(1).unique()
    if metrics is None:
        metrics = all_metrics
    else:
        if not all(metric in all_metrics for metric in metrics):
            raise ValueError("没有在数据中找到metric名称")
    if models is None:
        models = all_models
    else:
        if not all(model in all_models for model in models):
            raise ValueError("没有在数据中找到model名称")
    # 绘图， 每个metric对应一张图，图中有len(models)条线
    width = params.width[width]
    # 计算一共有多少行
    if len(metrics) % nline == 0:
        nrow = len(metrics) // nline
    else:
        nrow = len(metrics) // nline + 1
    # 创建画布
    fig = plt.figure(figsize=(width, height * nrow))
    gs = gridspec.GridSpec(nrow, nline)
    # 绘制每个子图
    for i, metric in enumerate(metrics):
        # 根据i计算出此时子图的位置
        row = i // nline
        col = i % nline
        ax = fig.add_subplot(gs[row, col])
        # 绘制线
        for model in models:
            ax.plot(data.loc[metric, model],
                    label=model,
                    marker="o",
                    linewidth=1,
                    )
            # 缩小x轴标签
            plt.setp(ax.get_xticklabels(), rotation=25)
            # 设置y轴标签个数为5
            ax.yaxis.set_major_locator(plt.MaxNLocator(5))
        ax.set_title(f"({i + 1}) {metric}")
    plt.tight_layout()
    # 设置字体大小
    # 所有的图片共用一个图例，图例在最下方
    fig.legend(models, loc="lower center", ncol=len(models), frameon=False)
    plt.subplots_adjust(bottom=0.1)  # 调整底部边距
    plt.show()
    if save_path is not None:
        fig.savefig(save_path)


def plot_streamflow(data_list: List[DataFrame],
                    y_lim: Optional[List[float]] = None,
                    save_path: Optional[str] = None,
                    color_lists: Optional[List[List[str]]] = None,
                    width: Optional[str] = "Double column (full width)",
                    height: Optional[Union[int, float]] = 2,
                    share_x_label: bool = True,
                    legend_loc: str = "upper center",
                    ) -> None:
    """
    将多条流量过程线绘制在一张图中，每个子图包含不同的数据集。

    :param data_list: 用于绘制的数据列表，每个元素是一个DataFrame
    :param y_lim: y轴的范围，默认为None，表示自动调整
    :param save_path: 保存路径，默认为None，表示不保存
    :param color_lists: 每个子图的颜色列表
    :param width: 选择绘制的图表的宽度，默认为"Double column (full width)"，可选值为"Minimal width", "Single column", "1.5 column", "Double column (full width)"
    :param height: 选择绘制的图表的高度，默认为2，单位为inch
    :param share_x_label: 是否共享x轴标签，默认为True
    :param legend_loc: 图例的位置，默认为"upper center"
    """
    width = params.width[width]
    n_plots = len(data_list)

    fig = plt.figure(figsize=(width, height * n_plots))
    gs = gridspec.GridSpec(n_plots, 1)

    for i, data in enumerate(data_list):
        ax = fig.add_subplot(gs[i])
        color_list = color_lists[i] if color_lists else None
        if color_list is not None:
            plt.rcParams['axes.prop_cycle'] = plt.cycler(color=color_list)
        for column in data.columns:
            ax.plot(data[column], label=column,
                    # 设置线宽
                    # linewidth=0.5,
                    )
        if y_lim is not None:
            ax.set_ylim(y_lim)
        # 设置x轴标签不要重合
        # fig.autofmt_xdate()
        # 在图的左上角添加一个符号
        ax.annotate(f"({i + 1})", xy=(0.015, 0.95), xycoords='axes fraction',
                    ha='center', va='center')
        ax.legend(frameon=False, loc=legend_loc)
        ax.set_ylabel("Flow($\mathrm{m}^3/\mathrm{s}$)")
        if share_x_label and i < n_plots - 1:
            ax.set_xticks([])  # 隐藏除最后一个子图外的x轴刻度
        else:
            ax.set_xlabel("Time")

    plt.tight_layout()
    if save_path is not None:
        fig.savefig(save_path)
    plt.show()


def plot_cdf(dataframe,
             ax,
             title: Optional[str] = None,
             ) -> None:
    """
    绘制流域某个指标的累计cdf

    :param dataframe: 用于绘制的数据，index为gauge_id，columns为不同的模型
    :param ax: 用于绘制的子图
    :param title: 子图的标题，默认为None
    """
    for column in dataframe.columns:
        data = dataframe[column].dropna()
        data = data.sort_values()
        # 如果有负值，就设置为0
        data[data < 0] = 0
        y = np.arange(1, len(data) + 1) / len(data)
        ax.plot(data, y, label=column)
        # 加上y轴标签： CDF
        ax.set_ylabel("CDF")
        # ax.set_xlim(0, 1)
    if title:
        ax.set_title(title)


def plot_multiple_cdfs(dataframes: List[DataFrame],
                       columns: int = 3,
                       width: str = "Double column (full width)",
                       height: Optional[Union[int, float]] = 2,
                       titles: Optional[List[str]] = None,
                       save_path: Optional[str] = None) -> None:
    """
    绘制多个CDF子图

    :param dataframes: 包含多个DataFrame的列表，每个DataFrame用于绘制一个子图
    :param columns: 每行的子图数量，默认为3
    :param width: 每个子图的宽度
    :param height: 每个子图的高度，默认为2，单位为inch
    :param titles: 每个子图的标题，默认为None
    :param save_path: 保存路径，默认为None，表示不保存
    """
    width = params.width[width]
    num_plots = len(dataframes)
    rows = (num_plots + columns - 1) // columns  # 计算行数，向上取整
    fig, axs = plt.subplots(rows, columns, figsize=(width, height * rows))

    # 将 axs 转为一维数组以便于迭代
    axs = axs.flatten()

    for i, ax in enumerate(axs):
        if i < num_plots:
            title = f"({i + 1}) {titles[i]}" if titles and i < len(titles) else f"({i + 1})"
            plot_cdf(dataframes[i], ax, title)
        else:
            fig.delaxes(ax)  # 删除多余的子图

    plt.tight_layout()
    # 设置所有子图公用一个图例，注意只有一个图例
    handles, labels = axs[0].get_legend_handles_labels()
    fig.legend(handles, labels, loc='lower right', frameon=False, ncols=len(labels))
    if save_path:
        plt.savefig(save_path)

    plt.show()
