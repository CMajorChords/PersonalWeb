from typing import List, Tuple, Optional
from torch.utils.data import Dataset
from torch import Tensor
from pandas import DataFrame
from utils.dataset.index import index_single_basin_timeseries


class HydroDatasetSingleBasinWithoutAttributes(Dataset):
    """
    为单个流域的时间序列数据构建的Dataset
    """

    def __init__(self,
                 timeseries: DataFrame,
                 target: str,
                 lookback: int,
                 horizon: int,
                 features_lookback: Optional[List[str]] = None,
                 features_bidirectional: Optional[List[str]] = None,
                 ):
        """
        初始化HydroDatasetBasins。

        :param timeseries: 时间序列数据，DataFrame。index必须是时间戳
        :param target: 要预测的时间序列的列名
        :param lookback: 过去时间步数
        :param horizon: 未来时间步数
        :param features_lookback: 只将lookback输入到网络的特征
        :param features_bidirectional: 将lookback和horizon全部输入到网络的特征
        """
        self.lookback = lookback
        self.horizon = horizon
        self.target = Tensor(timeseries[target].values)
        match features_lookback, features_bidirectional:
            case (None, None):
                raise ValueError("过去特征和双向特征不能同时为空")
            case (None, _):
                self.features_bidirectional = Tensor(timeseries[features_bidirectional].values)
                self.num_bidirectional_features = len(features_bidirectional)
                self.get_item_func = self.get_item_bidirectional
            case (_, None):
                self.features_lookback = Tensor(timeseries[features_lookback].values)
                self.num_lookback_features = len(features_lookback)
                self.get_item_func = self.get_item_lookback
            case (_, _):
                self.features_lookback = Tensor(timeseries[features_lookback].values)
                self.num_lookback_features = len(features_lookback)
                self.features_bidirectional = Tensor(timeseries[features_bidirectional].values)
                self.num_bidirectional_features = len(features_bidirectional)
                self.get_item_func = self.get_item_lookback_bidirectional
        # 判断是否有静态属性数据
        self.timeseries_index \
            = index_single_basin_timeseries(timeseries=timeseries, target=target, lookback=lookback, horizon=horizon,
                                            features_lookback=features_lookback,
                                            features_bidirectional=features_bidirectional)

    def __len__(self) -> int:
        """
        获取样本数量。
        """
        return len(self.timeseries_index)

    def __getitem__(self, idx: int):
        """
        获取单个样本的输入和target输出。

        :param self: HydroDatasetBasins类的实例
        :param idx: 样本的索引
        :return: 输入、attributes输入和target输出
        """
        return self.get_item_func(idx)

    def get_item_lookback(self, idx: int) -> Tuple[Tensor, Tensor]:
        """
        获取单个样本的lookback输入和target输出。
        """
        lookback = self.lookback
        horizon = self.horizon
        timeseries_index = self.timeseries_index[idx]
        input_timeseries = self.features_lookback[timeseries_index:timeseries_index + lookback]
        output_target = self.target[timeseries_index + lookback:timeseries_index + lookback + horizon]
        return input_timeseries, output_target

    def __getitem__(self, idx: int):
        """
        获取单个样本的输入和target输出。

        :param self: HydroDatasetBasins类的实例
        :param idx: 样本的索引
        :return: 输入、attributes输入和target输出
        """
        return self.get_item_func(idx)

    def get_item_bidirectional(self, idx: int) -> Tuple[Tensor, Tensor]:
        """
        获取单个样本的bidirectional输入和target输出。
        """
        lookback = self.lookback
        horizon = self.horizon
        timeseries_index = self.timeseries_index[idx]
        input_timeseries = self.features_bidirectional[timeseries_index:timeseries_index + lookback + horizon]
        output_target = self.target[timeseries_index + lookback:timeseries_index + lookback + horizon]
        return input_timeseries, output_target

    def get_item_lookback_bidirectional(self, idx: int) -> Tuple[Tensor, Tensor, Tensor]:
        """
        获取单个样本的lookback和bidirectional输入和target输出。
        """
        lookback = self.lookback
        horizon = self.horizon
        timeseries_index = self.timeseries_index[idx]
        input_timeseries_lookback = self.features_lookback[timeseries_index:timeseries_index + lookback]
        input_timeseries_bidirectional = self.features_bidirectional[
                                         timeseries_index:timeseries_index + lookback + horizon]
        output_target = self.target[timeseries_index + lookback:timeseries_index + lookback + horizon]
        return input_timeseries_lookback, input_timeseries_bidirectional, output_target
