# 为降雨径流模拟深度学习模型准备dataset和dataloader
from typing import List, Optional, Union
from pandas import DataFrame
from utils.dataset.check import check_multiindex

from utils.dataset.dataset.hydro_dataset_multi_basin_with_attributes import HydroDatasetMultiBasinWithAttributes
from utils.dataset.dataset.hydro_dataset_multi_basin_without_attributes import HydroDatasetMultiBasinWithoutAttributes
from utils.dataset.dataset.hydro_dataset_single_basin_with_attributes import HydroDatasetSingleBasinWithAttributes
from utils.dataset.dataset.hydro_dataset_single_basin_without_attributes import HydroDatasetSingleBasinWithoutAttributes


def get_dataset(timeseries: DataFrame,
                target: str,
                lookback: int,
                horizon: int,
                attributes: Optional[DataFrame] = None,
                features_lookback: Optional[List[str]] = None,
                features_bidirectional: Optional[List[str]] = None,
                ) -> Union[HydroDatasetMultiBasinWithAttributes,
HydroDatasetMultiBasinWithoutAttributes,
HydroDatasetSingleBasinWithAttributes,
HydroDatasetSingleBasinWithoutAttributes
]:
    """
    根据输入数据的类型，返回不同的Dataset对象。

    :param timeseries: 时间序列数据，DataFrame。index必须是MultiIndex，level0为流域id，level1为时间戳
    :param target: 要预测的时间序列的列名
    :param lookback: 过去时间步数
    :param horizon: 未来时间步数
    :param attributes: 静态属性数据，可以是DataFrame或者Series。index必须是流域id
    :param features_lookback: 只将lookback输入到网络的特征
    :param features_bidirectional: 将lookback和horizon全部输入到网络的特征
    :return: HydroDatasetMultiBasinWithAttributes, HydroDatasetMultiBasinWithoutAttributes,
             HydroDatasetSingleBasinWithAttributes, HydroDatasetSingleBasinWithoutAttributes
    """
    # 检查timeseries是否是multiindex
    if isinstance(timeseries, DataFrame):
        # 如果是MultiIndex，则为多流域数据
        if check_multiindex(timeseries):
            if attributes is None:
                dataset = HydroDatasetMultiBasinWithoutAttributes(timeseries=timeseries,
                                                                  target=target,
                                                                  lookback=lookback,
                                                                  horizon=horizon,
                                                                  features_lookback=features_lookback,
                                                                  features_bidirectional=features_bidirectional)
            else:
                dataset = HydroDatasetMultiBasinWithAttributes(timeseries=timeseries,
                                                               target=target,
                                                               lookback=lookback,
                                                               horizon=horizon,
                                                               attributes=attributes,
                                                               features_lookback=features_lookback,
                                                               features_bidirectional=features_bidirectional)
        # 如果不是MultiIndex，则为单流域数据
        else:
            if attributes is None:
                dataset = HydroDatasetSingleBasinWithoutAttributes(timeseries=timeseries,
                                                                   target=target,
                                                                   lookback=lookback,
                                                                   horizon=horizon,
                                                                   features_lookback=features_lookback,
                                                                   features_bidirectional=features_bidirectional)
            else:
                dataset = HydroDatasetSingleBasinWithAttributes(timeseries=timeseries,
                                                                target=target,
                                                                lookback=lookback,
                                                                horizon=horizon,
                                                                attributes=attributes,
                                                                features_lookback=features_lookback,
                                                                features_bidirectional=features_bidirectional)
    else:
        raise ValueError("timeseries必须是DataFrame")
    return dataset
