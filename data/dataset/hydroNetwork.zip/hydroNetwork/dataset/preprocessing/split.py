# 划分时间序列数据集为多个子集
from typing import List, Union
from pandas import DataFrame, Series, concat, IndexSlice, to_datetime
from datetime import datetime
from tqdm.contrib.concurrent import process_map
from utils.dataset.check import check_multiindex, check_same_class


def split_single_basin_timeseries(data: Union[DataFrame, Series],
                                  split_list: Union[List[int], List[datetime]],
                                  ) -> List[DataFrame]:
    """
    将单个流域的时间序列数据集按照样本数量或时间点划分为多个子集

    :param data: 单个流域的数据集。index为时间
    :param split_list: 用于划分数据集的列表。列表元素为整数或时间。整数表示样本数量，时间表示时间点
    :return: 划分后的多个子集
    """
    if check_same_class(split_list, int):
        if sum(split_list) >= len(data):
            raise ValueError("各子集样本数量之和大于数据集样本数量")
        else:
            split_data = []
            subset_start = 0
            for subset_len in split_list:  # 按照指定的样本数量划分数据集
                split_data.append(data.iloc[subset_start:subset_start + subset_len])
                subset_start += subset_len
            return split_data
    elif check_same_class(split_list, datetime):
        split_list.sort()
        if split_list[-1] >= data.index[-1][1]:
            raise ValueError("划分时间点大于数据集最后时间")
        elif split_list[0] <= data.index[0][1]:
            raise ValueError("划分时间点小于数据集第一个时间")
        else:
            split_data = []
            for idx, subset_start in enumerate(split_list[:-1]):
                subset_end = split_list[idx + 1]
                split_data.append(
                    data.loc[IndexSlice[:, subset_start:subset_end], :]
                )
            return split_data
    else:
        raise ValueError("划分列表元素必须为整数或时间")


def split_timeseries(data: Union[DataFrame, Series],
                     split_list: Union[List[int], List[datetime], List[str],]
                     ) -> List[DataFrame]:
    """
    将单个流域或多个流域的时间序列数据集按照样本数量或时间点划分为多个子集

    :param data: 数据集。单个流域的数据集index为时间。多个流域的数据集index应为multiindex，第一层为流域id，第二层为时间
    :param split_list: 用于划分数据集的列表。列表元素为整数或时间。整数表示样本数量，时间表示时间点
    :return: 划分后的多个子集
    """
    # 如果split_list是字符串，转换为时间
    if check_same_class(split_list, str):
        split_list = list(map(to_datetime, split_list))
    # 检查数据集中包含单个流域还是多个流域，看看有几个level
    if check_multiindex(data):
        # 多进程处理每个流域
        gauge_id_list = data.index.get_level_values(0).unique()  # 获取所有流域id
        len_gauge_id_list = len(gauge_id_list)
        data_split = zip(*process_map(split_single_basin_timeseries,
                                      [group_data for _, group_data in data.groupby(level=0)],
                                      [split_list] * len_gauge_id_list,
                                      desc=f"正在划分{len_gauge_id_list}个流域的数据集",
                                      total=len_gauge_id_list,
                                      )
                         )
        return list(map(lambda x: concat(x, axis=0), data_split))
    else:
        return split_single_basin_timeseries(data, split_list)
