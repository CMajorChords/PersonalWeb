# LSTM类模型的实现
import torch
import torch.nn as nn


class EncoderDecoderLSTM(nn.Module):
    def __init__(self,
                 lookback: int,
                 horizon: int,
                 timeseries_features_num: int,
                 timeseries_embedding_dim: int,
                 timeseries_embedding_num: int,
                 static_features_num: int,
                 static_embedding_dim: int,
                 static_embedding_num: int,
                 encoder_hidden_size: int = 256,
                 decoder_hidden_size: int = 256,
                 num_layers: int = 1,
                 dropout: float = 0,
                 ):
        super(EncoderDecoderLSTM, self).__init__()
        self.lookback = lookback
        self.horizon = horizon
        # 时间序列特征嵌入
        self.timeseries_embedding = nn.Sequential(
            nn.Linear(timeseries_features_num, timeseries_embedding_dim),
            nn.LeakyReLU(),
        )
        for _ in range(timeseries_embedding_num - 1):
            self.timeseries_embedding.add_module(
                f"layer_{_}",
                nn.Sequential(
                    nn.Linear(timeseries_embedding_dim, timeseries_embedding_dim),
                    nn.LeakyReLU(),
                )
            )
        # 静态特征嵌入
        self.static_embedding = nn.Sequential(
            nn.Linear(static_features_num, static_embedding_dim),
            nn.LeakyReLU(),
        )
        for _ in range(static_embedding_num - 1):
            self.static_embedding.add_module(
                f"layer_{_}",
                nn.Sequential(
                    nn.Linear(static_embedding_dim, static_embedding_dim),
                    nn.LeakyReLU(),
                )
            )
        # 编码器
        self.encoder_lstm = nn.LSTM(input_size=timeseries_embedding_dim + static_embedding_dim,
                                    hidden_size=encoder_hidden_size,
                                    num_layers=num_layers,
                                    dropout=dropout,
                                    batch_first=True,
                                    bidirectional=False)
        # 状态转移（线性变换）
        self.cell_linear = nn.Sequential(
            nn.Linear(encoder_hidden_size, decoder_hidden_size),
            nn.LeakyReLU(),
            nn.Linear(decoder_hidden_size, decoder_hidden_size),
        )
        self.hidden_linear = nn.Sequential(
            nn.Linear(encoder_hidden_size, decoder_hidden_size),
            nn.LeakyReLU(),
            nn.Linear(decoder_hidden_size, decoder_hidden_size),
        )
        # 解码器
        self.decoder_lstm = nn.LSTM(input_size=timeseries_embedding_dim + static_embedding_dim,
                                    hidden_size=decoder_hidden_size,
                                    num_layers=num_layers,
                                    dropout=dropout,
                                    batch_first=True,
                                    bidirectional=False)
        self.decoder_linear = nn.Linear(decoder_hidden_size, 1)

    def forward(self,
                bidirectional_timeseries,
                attributes,
                ):
        # 嵌入时间序列特征
        timeseries_input = self.timeseries_embedding(bidirectional_timeseries)
        ts_input_encoder = timeseries_input[:, :self.lookback, :]
        ts_input_decoder = timeseries_input[:, self.lookback:self.lookback + self.horizon, :]
        # 嵌入静态特征
        attributes_input = self.static_embedding(attributes)
        # 拼接时间序列和静态特征
        # 首先将静态特征的维度扩展到与时间序列特征相同
        attributes_input_encoder = attributes_input.unsqueeze(1).expand(-1, self.lookback, -1)
        attributes_input_decoder = attributes_input.unsqueeze(1).expand(-1, self.horizon, -1)
        encoder_input = torch.cat([ts_input_encoder, attributes_input_encoder], dim=-1)
        decoder_input = torch.cat([ts_input_decoder, attributes_input_decoder], dim=-1)
        # 编码
        _, (encoder_hidden, encoder_cell) = self.encoder_lstm(encoder_input)
        # 解码
        decoder_output, _ = self.decoder_lstm(decoder_input, (encoder_hidden, encoder_cell))
        decoder_output = self.decoder_linear(decoder_output)
        decoder_output = decoder_output.squeeze(-1)
        return decoder_output
