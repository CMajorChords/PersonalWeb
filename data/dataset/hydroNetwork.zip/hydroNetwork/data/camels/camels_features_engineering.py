# 对CAMELS数据集进行特征工程处理
from typing import List, Optional, Tuple
from utils.data.camels.camels import load_timeseries, load_attributes, get_gauge_id
import utils.dataset.preprocessing.transform as tf
from utils.dataset.preprocessing import normalize
from numpy import sin, cos, pi
from pandas import DataFrame
import torch


def preprocess_camels(gauge_id_list: Optional[List[str]] = None,
                      set_streamflow_to_mm: bool = True,
                      add_date_features: bool = False,
                      ) -> Tuple[DataFrame, DataFrame]:
    """
    对CAMELS数据集进行特征工程处理

    :param gauge_id_list: 要处理的流域id列表
    :param set_streamflow_to_mm: 是否将流域的流量单位设置为mm
    :param add_date_features: 是否添加日期特征
    :return: 包含特征工程处理后的时间序列数据和静态数据的元组
    """
    if gauge_id_list is None:
        gauge_id_list = get_gauge_id()
    timeseries_data = load_timeseries(gauge_id=gauge_id_list, multi_process=True)
    static_data = load_attributes(gauge_id_list=gauge_id_list)

    # 静态数据数据转换
    log_transform_features = ['elev_mean', 'slope_mean', 'p_mean', 'pet_mean',
                              'aridity', 'high_prec_dur', 'low_prec_dur',
                              'soil_depth_pelletier', 'soil_depth_statsgo', 'soil_conductivity', ]
    for features in log_transform_features:
        static_data[features] = tf.log_transform(static_data[features])
    # 移出流域面积
    area = static_data['area_gages2']
    # 对静态数据进行标准化
    static_data, static_scale_params = normalize(static_data)
    # 保存标准化参数
    static_scale_params.to_csv("data/camels/camels_static_scale_params.csv")

    # 时间序列数据转换
    # 将径流数据单位从立方英尺每秒转换为立方米每天
    timeseries_data['streamflow'] = timeseries_data['streamflow'] * 0.0283168 * 86400
    if set_streamflow_to_mm:
        static_data.drop(columns=['area_gages2'], inplace=True)
        # 将径流数据单位从立方米每天转换为毫米每天，除以对应的流域面积（平方千米）
        timeseries_data['streamflow'] = timeseries_data['streamflow'] / area.loc[
            timeseries_data.index.get_level_values(0)].values / 1000
    # 对降水、径流和蒸汽压进行对数变换
    timeseries_data['prcp(mm/day)'] = tf.log_transform(timeseries_data['prcp(mm/day)'])
    timeseries_data['streamflow'] = tf.log_transform(timeseries_data['streamflow'])
    timeseries_data['vp(Pa)'] = tf.log_transform(timeseries_data['vp(Pa)'])
    timeseries_data, timeseries_scale_params = normalize(timeseries_data)
    # 补充一列，如果有降水就是1，没有就是0，注意降水都是正数
    timeseries_data['has_prcp'] = timeseries_data['prcp(mm/day)'].apply(lambda x: 1 if x > 0 else 0)
    # 添加日期特征
    if add_date_features:
        datetime = timeseries_data.index.get_level_values(1)
        # 添加列，表示年份，年份应为整数，第一年为1980，最后一年为2014
        timeseries_data['year'] = datetime.year - 1980.
        # 添加列，表示月份的sin和cos
        timeseries_data['month_sin'] = sin(2 * pi * datetime.month / 12)
        timeseries_data['month_cos'] = cos(2 * pi * datetime.month / 12)
    # 保存标准化参数
    timeseries_scale_params.to_csv("data/camels/camels_timeseries_scale_params.csv")
    # 将所有数据化为float32
    timeseries_data = timeseries_data.astype('float32')
    static_data = static_data.astype('float32')
    torch.set_float32_matmul_precision('high')
    return timeseries_data, static_data
