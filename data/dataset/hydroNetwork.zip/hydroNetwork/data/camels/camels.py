# 创建用于处理camels数据集的函数、类
from os import cpu_count
from typing import List, Tuple, Union, Sequence, Optional
from concurrent.futures import ProcessPoolExecutor
import pandas as pd
from pandas import DataFrame
from xarray import Dataset
from tqdm.contrib.concurrent import thread_map
import utils.data.camels.camels_params as params


def get_gauge_id(root_path: str = params.camels_root_path,
                 get_huc_02: bool = False,
                 ignore_gauge_id: Optional[List[str]] = None,
                 n: Optional[int] = None,
                 ) -> Union[
    str,
    List[str],
    Tuple[str, str],
    Tuple[List[str], List[str]]
]:
    """
    获取指定流域ID。如果没有指定流域ID，则返回所有流域ID

    :param root_path: CAMELS数据集根目录
    :param get_huc_02: 是否获取HUC02编码
    :param n: 流域ID数量，默认为选择所有流域ID
    :param ignore_gauge_id: 忽略的流域ID列表
    :return: n个随机流域ID和对应的HUC02编码（可选）
    """
    camels_name = load_single_type_attributes("name", root_path)
    # 删除忽略的流域ID
    if ignore_gauge_id is not None:
        camels_name.drop(index=ignore_gauge_id, inplace=True)
    # 如果n为None，则返回所有流域ID, 否则返回n个随机流域ID
    data = camels_name if n is None else camels_name.sample(n)
    # 如果get_huc_02为True，则返回流域ID和对应的HUC02编码，否则只返回流域ID
    gauge_id_list = data.index.tolist()
    if get_huc_02:
        huc_02_list = data["huc_02"].tolist()
        return (gauge_id_list[0], huc_02_list[0]) if n == 1 else (gauge_id_list, huc_02_list)
    else:
        return gauge_id_list[0] if n == 1 else gauge_id_list


def load_single_type_attributes(attr: str,
                                root_path: str = params.camels_root_path,
                                ) -> DataFrame:
    """
    加载CAMELS数据集中的单个属性种类的属性数据

    :param root_path: CAMELS数据集根目录
    :param attr: 属性种类名称
    :return: 单个属性种类的属性数据
    """
    path = root_path + f"/camels_{attr}.txt"
    dtype = {"gauge_id": str, "huc_02": str, } if attr == "name" else {"gauge_id": str, }
    return pd.read_csv(path,
                       index_col="gauge_id",
                       dtype=dtype,
                       sep=";",
                       )


def load_attributes(gauge_id_list: Optional[List[str]] = None,
                    attr_type_name_list: Optional[List[str]] = None,
                    root_path: str = params.camels_root_path,
                    use_attr_name: Optional[List[str]] = None,
                    ) -> DataFrame:
    """
    加载CAMELS数据集中指定流域的属性数据

    :param gauge_id_list: 流域ID列表, 默认为None, 表示加载所有流域的属性数据
    :param attr_type_name_list: 属性种类名称列表
    :param root_path: CAMELS数据集根目录，默认为"camels_params"中的root_path
    :param use_attr_name: 使用的属性名称列表
    :return: 加载指定属性种类的所有属性数据
    """
    # 首先加载指定属性种类的属性数据
    if attr_type_name_list is None:
        attr_type_name_list = params.attributes_type_name
    len_attr_type_name_list = len(attr_type_name_list)
    attributes = pd.concat(
        thread_map(load_single_type_attributes,
                   attr_type_name_list,
                   [root_path] * len_attr_type_name_list,
                   desc=f"正在加载{len_attr_type_name_list}类流域静态属性",
                   total=len_attr_type_name_list,
                   ),
        axis=1)
    # 删除忽略的属性
    if use_attr_name is None:
        use_attr_name = params.use_attribute_name
    for attribute in use_attr_name:  # 检查忽略的属性是否在属性数据中
        if attribute not in attributes.columns:
            raise ValueError(f"属性{attribute}不在属性数据中")
    attributes = attributes[use_attr_name]
    if gauge_id_list is not None:
        attributes = attributes.loc[gauge_id_list]
    return attributes


def split_list(sequence: Sequence, n: int) -> List[List]:
    """
    将容器分成n份, 如果不能整除，则前面的部分比后面的部分多1个元素
    :param sequence: 待分割的容器
    :param n: 分割的份数
    :return: 分割后的列表
    """
    k, m = divmod(len(sequence), n)
    return [sequence[i * k + min(i, m):(i + 1) * k + min(i + 1, m)] for i in range(n)]


def load_single_basin_forcing(gauge_id: str,
                              huc_02: Optional[str] = None,
                              root_path: str = params.camels_root_path,
                              source: str = params.forcing_source,
                              ignore_columns: Optional[List[str]] = None,
                              add_datetime: bool = True,
                              ) -> DataFrame:
    """
    加载单个流域的降水数据

    :param gauge_id: 流域ID
    :param huc_02: 流域的HUC02编码
    :param root_path: CAMELS数据集根目录，默认为"camels_params"中的root_path
    :param source: 气象强迫数据来源, 默认为"daymet", 可选值为"daymet"、“maurer"和”nldas"
    :param ignore_columns: 忽略的列名列表
    :param add_datetime: 是否添加datetime列，若添加，将删去Year，Mnth和Day三列，并添加datetime列为索引
    :return: 单个流域的气象强迫数据
    """
    # 如果没有指定HUC02编码，则从流域名称数据中获取
    if huc_02 is None:
        huc_02 = load_single_type_attributes("name", root_path).loc[gauge_id, "huc_02"]
    # 根据降水数据来源获得数据路径
    path = root_path + ("/basin_timeseries_v1p2_metForcing_obsFlow"
                        "/basin_dataset_public_v1p2/basin_mean_forcing/") + source
    if source == "daymet":
        path = path + f"/{huc_02}/{gauge_id}_lump_cida_forcing_leap.txt"
    elif source == "maurer":
        path = path + f"/{huc_02}/{gauge_id}_lump_maurer_forcing_leap.txt"
    elif source == "nldas":
        path = path + f"/{huc_02}/{gauge_id}_lump_nldas_forcing_leap.txt"
    else:
        raise ValueError(f"不支持的数据来源{source}")
    # 读取并修改数据
    data = pd.read_csv(path,
                       skiprows=3,
                       sep=r"\s+",
                       )
    if add_datetime:  # 根据年月日形成datetime列
        data["datetime"] = pd.to_datetime(data[["Year", "Mnth", "Day"]].astype(str).agg("-".join, axis=1))
        data.set_index("datetime", inplace=True)
        data.drop(columns=["Year", "Mnth", "Day"], inplace=True)
    if ignore_columns is None:
        ignore_columns = params.ignore_precip_cols
    data.drop(columns=ignore_columns, inplace=True)
    data.columns.name = "forcing_type"
    return data


def load_basins_forcing_with_threads(gauge_id_list: List[str],
                                     huc_02_list: List[str],
                                     root_path: str,
                                     source: str,
                                     ignore_columns: Optional[List[str]],
                                     ) -> DataFrame:
    """
    多线程加载CAMELS数据集中部分流域的降水数据
    :param gauge_id_list: 流域ID列表
    :param huc_02_list: 流域的HUC02编码列表
    :param root_path: CAMELS数据集根目录，默认为"camels_params"中的root_path
    :param source: 气象强迫数据来源, 默认为"daymet", 可选值为"daymet"、“maurer"和”nldas"
    :param ignore_columns: 忽略的列名列表
    :return:多个流域的气象强迫数据
    """
    len_gauge_id_list = len(gauge_id_list)
    return pd.concat(
        thread_map(load_single_basin_forcing,
                   gauge_id_list, huc_02_list,
                   [root_path] * len_gauge_id_list,
                   [source] * len_gauge_id_list,
                   [ignore_columns] * len_gauge_id_list,
                   desc=f"正在加载{len_gauge_id_list}个流域的气象强迫数据",
                   total=len_gauge_id_list,
                   ),
        keys=gauge_id_list,
        names=["gauge_id", "datetime"],
        axis=0,
    )


def load_basins_forcing(gauge_id_list: Optional[List[str]] = None,
                        root_path: str = params.camels_root_path,
                        source: str = params.forcing_source,
                        ignore_columns: Optional[List[str]] = None,
                        multi_process: bool = False,
                        to_xarray: bool = False,
                        ) -> Union[DataFrame, Dataset]:
    """
    多线程加载CAMELS数据集中所有流域的降水数据

    :param gauge_id_list: 流域ID列表
    :param root_path: CAMELS数据集根目录，默认为"camels_params"中的root_path
    :param source: 气象强迫数据来源, 默认为"daymet", 可选值为"daymet"、“maurer"和”nldas"
    :param ignore_columns: 忽略的列名列表
    :param multi_process: 是否使用多进程
    :param to_xarray: 是否转换为xarray格式
    :return: 所有流域的降水数据
    """
    # 获取流域ID列表和对应的HUC02编码
    if gauge_id_list is None:  # 如果没有指定流域ID列表，则加载所有流域的ID, 并获取对应的HUC02编码
        gauge_id_list, huc_02_list = get_gauge_id(root_path, True)
    else:  # 如果指定了流域ID列表，则获取对应的HUC02编码
        huc_02_list = load_single_type_attributes("name", root_path).loc[gauge_id_list, "huc_02"].tolist()
    # 判断是否使用多进程, 并加载所有流域的降水数据
    if multi_process:
        num_workers = cpu_count()
        # 先将流域ID列表和huc_02列表分成num_workers份
        gauge_id_lists = split_list(gauge_id_list, num_workers)
        huc_02_lists = split_list(huc_02_list, num_workers)
        # 使用多进程加载所有流域的降水数据
        with ProcessPoolExecutor() as executor:
            print("正在使用多个进程加载流域的降水数据")
            result = pd.concat(executor.map(load_basins_forcing_with_threads,
                                            gauge_id_lists, huc_02_lists,
                                            [root_path] * num_workers,
                                            [source] * num_workers,
                                            [ignore_columns] * num_workers,
                                            ),
                               axis=0, )
    else:
        result = load_basins_forcing_with_threads(gauge_id_list, huc_02_list,
                                                  root_path, source, ignore_columns)
    if to_xarray:
        result = result.to_xarray()
    return result


def load_forcing(gauge_id: Optional[Union[str, List[str]]] = None,
                 root_path: str = params.camels_root_path,
                 source: str = params.forcing_source,
                 ignore_columns: Optional[List[str]] = None,
                 add_datetime: bool = True,
                 multi_process: bool = False,
                 to_xarray: bool = False,
                 ) -> Union[DataFrame, Dataset]:
    """
    加载CAMELS数据集中所有流域的降水数据

    :param gauge_id: 流域ID，可以是str(表示单个流域id)，也可以是List[str](表示多个流域id)
    :param root_path: CAMELS数据集根目录，默认为"camels_params"中的root_path
    :param source: 降水数据来源, 默认为"daymet", 可选值为"daymet"、“maurer"和”nldas"
    :param ignore_columns: 忽略的列名列表
    :param add_datetime: 是否添加datetime列，若添加，将删去Year，Mnth和Day三列，并添加datetime列为索引，仅对单个流域有效
    :param multi_process: 是否使用多进程，仅对多个流域有效
    :param to_xarray: 是否转换为xarray格式，仅对多个流域有效
    :return: 指定流域的降水数据
    """
    if gauge_id is None:
        return load_basins_forcing(gauge_id_list=None,
                                   root_path=root_path,
                                   source=source,
                                   ignore_columns=ignore_columns,
                                   multi_process=multi_process,
                                   to_xarray=to_xarray)
    elif isinstance(gauge_id, str):
        return load_single_basin_forcing(gauge_id,
                                         root_path=root_path,
                                         source=source,
                                         ignore_columns=ignore_columns,
                                         add_datetime=add_datetime)
    elif isinstance(gauge_id, list):
        return load_basins_forcing(gauge_id_list=gauge_id,
                                   root_path=root_path,
                                   source=source,
                                   ignore_columns=ignore_columns,
                                   multi_process=multi_process,
                                   to_xarray=to_xarray)


def load_single_basin_streamflow(gauge_id: str,
                                 huc_02: Optional[str] = None,
                                 root_path: str = params.camels_root_path,
                                 add_datetime: bool = True,
                                 ) -> DataFrame:
    """
    加载单个流域的流量数据

    :param gauge_id: 流域ID
    :param huc_02: 流域的HUC02编码，如果没有指定，则从流域名称数据中获取
    :param root_path: CAMELS数据集根目录，默认为"camels_params"中的root_path
    :param add_datetime: 是否添加datetime列，若添加，将删去Year，Mnth和Day三列，并添加datetime列为索引
    :return: 单个流域的流量数据
    """
    # 如果没有指定HUC02编码，则从流域名称数据中获取
    if huc_02 is None:
        huc_02 = load_single_type_attributes("name", root_path).loc[gauge_id, "huc_02"]
    # 读取数据
    path = root_path + (f"/basin_timeseries_v1p2_metForcing_obsFlow/"
                        f"basin_dataset_public_v1p2/usgs_streamflow/{huc_02}/{gauge_id}_streamflow_qc.txt")
    data = pd.read_csv(path,
                       header=None,
                       names=["gauge_id", "Year", "Mnth", "Day", "streamflow", "qc"],
                       sep=r"\s+",
                       )
    # 数据处理
    data["streamflow"] = data["streamflow"].where(data["qc"] != "M")  # 如果qc是M，则将流量数据设为NaN
    data.drop(columns="qc", inplace=True)
    if add_datetime:  # 根据年月日形成datetime列
        data["datetime"] = pd.to_datetime(data[["Year", "Mnth", "Day"]].astype(str).agg("-".join, axis=1))
        data.set_index("datetime", inplace=True)
        data.drop(columns=["Year", "Mnth", "Day"], inplace=True)
    data.drop(columns="gauge_id", inplace=True)  # 删除gauge_id列
    data.columns.name = "streamflow"
    return data


def load_basins_streamflow_with_threads(gauge_id_list: List[str],
                                        huc_02_list: List[str],
                                        root_path: str,
                                        ) -> DataFrame:
    """
    多线程加载CAMELS数据集中部分流域的流量数据

    :param gauge_id_list: 流域ID列表
    :param huc_02_list: 流域的HUC02编码列表
    :param root_path: CAMELS数据集根目录，默认为"camels_params"中的root_path
    :return: 所有流域的流量数据
    """
    len_gauge_id_list = len(gauge_id_list)
    return pd.concat(
        thread_map(load_single_basin_streamflow,
                   gauge_id_list, huc_02_list,
                   [root_path] * len_gauge_id_list,
                   desc=f"正在加载{len_gauge_id_list}个流域的流量数据",
                   total=len_gauge_id_list,
                   ),
        keys=gauge_id_list,
        names=["gauge_id", "datetime"],
        axis=0,
    )


def load_basins_streamflow(gauge_id_list: Optional[List[str]] = None,
                           root_path: str = params.camels_root_path,
                           multi_process: bool = False,
                           to_xarray: bool = False,
                           ) -> Union[DataFrame, Dataset]:
    """
    加载CAMELS数据集中所有流域的流量数据

    :param gauge_id_list: 流域ID列表，如果为None，则加载所有流域的ID
    :param root_path: CAMELS数据集根目录，默认为"camels_params"中的root_path
    :param multi_process: 是否使用多进程
    :param to_xarray: 是否转换为xarray格式
    :return: 所有流域的流量数据
    """
    # 如果没有指定流域ID列表，则加载所有流域的ID
    if gauge_id_list is None:
        gauge_id_list, huc_02_list = get_gauge_id(root_path, True)
    else:
        huc_02_list = load_single_type_attributes("name", root_path).loc[gauge_id_list, "huc_02"].tolist()
    # 判断使用多线程还是多进程, 并加载所有流域的流量数据
    if multi_process:
        num_workers = cpu_count()
        # 先将流域ID列表和huc_02列表分成num_workers份
        gauge_id_lists = split_list(gauge_id_list, num_workers)
        huc_02_lists = split_list(huc_02_list, num_workers)
        # 使用多进程加载所有流域的流量数据
        with ProcessPoolExecutor() as executor:
            print("正在使用多个进程加载流域的流量数据")
            result = pd.concat(
                executor.map(load_basins_streamflow_with_threads,
                             gauge_id_lists, huc_02_lists,
                             [root_path] * num_workers,
                             ),
                axis=0,
            )
    else:
        result = load_basins_streamflow_with_threads(gauge_id_list, huc_02_list, root_path)
    if to_xarray:
        result = result.to_xarray()
    return result


def load_streamflow(gauge_id: Optional[Union[str, List[str]]] = None,
                    root_path: str = params.camels_root_path,
                    add_datetime: bool = True,
                    multi_process: bool = False,
                    to_xarray: bool = False,
                    ) -> Union[DataFrame, Dataset]:
    """
    加载CAMELS数据集中所有流域的流量数据

    :param gauge_id:流域ID，可以是str(表示单个流域id)，也可以是List[str](表示多个流域id)
    :param root_path:CAMELS数据集根目录，默认为"camels_params"中的root_path
    :param add_datetime:是否添加datetime列，若添加，将删去Year，Mnth和Day三列，并添加datetime列为索引，仅对单个流域有效
    :param multi_process:是否使用多进程，仅对多个流域有效
    :param to_xarray:是否转换为xarray格式，仅对多个流域有效
    :return:指定流域的流量数据
    """
    if gauge_id is None:
        return load_basins_streamflow(gauge_id_list=None,
                                      root_path=root_path,
                                      multi_process=multi_process,
                                      to_xarray=to_xarray)
    elif isinstance(gauge_id, str):
        return load_single_basin_streamflow(gauge_id,
                                            root_path=root_path,
                                            add_datetime=add_datetime)
    elif isinstance(gauge_id, list):
        return load_basins_streamflow(gauge_id_list=gauge_id,
                                      root_path=root_path,
                                      multi_process=multi_process,
                                      to_xarray=to_xarray)


def load_single_basin_timeseries(gauge_id: str,
                                 huc_02: Optional[str] = None,
                                 root_path: str = params.camels_root_path,
                                 source: str = params.forcing_source,
                                 ignore_columns: Optional[List[str]] = None,
                                 ) -> DataFrame:
    """
    加载单个流域的气象强迫和流量数据

    :param gauge_id: 流域ID
    :param huc_02: 流域的HUC02编码
    :param root_path: CAMELS数据集根目录，默认为"camels_params"中的root_path
    :param source: 降水数据来源, 默认为"daymet", 可选值为"daymet"、“maurer"和”nldas"
    :param ignore_columns: 忽略的列名列表
    :return: 单个流域的气象强迫和流量数据
    """
    forcing = load_single_basin_forcing(gauge_id, huc_02, root_path, source, ignore_columns)
    streamflow = load_single_basin_streamflow(gauge_id, huc_02, root_path)
    timeseries = pd.concat([forcing, streamflow], axis=1)
    timeseries.columns.name = "timeseries_type"
    return timeseries


def load_basins_timeseries_with_threads(gauge_id_list: List[str],
                                        huc_02_list: List[str],
                                        root_path: str,
                                        source: str,
                                        ignore_columns: Optional[List[str]],
                                        ) -> DataFrame:
    """
    多线程加载CAMELS数据集中部分流域的气象强迫和流量数据

    :param gauge_id_list: 流域ID列表
    :param huc_02_list: 流域的HUC02编码列表
    :param root_path: CAMELS数据集根目录，默认为"camels_params"中的root_path
    :param source: 降水数据来源, 默认为"daymet", 可选值为"daymet"、“maurer"和”nldas"
    :param ignore_columns: 忽略的列名列表
    :return: 所有流域的气象强迫和流量数据
    """
    len_gauge_id_list = len(gauge_id_list)
    return pd.concat(
        thread_map(load_single_basin_timeseries,
                   gauge_id_list, huc_02_list,
                   [root_path] * len_gauge_id_list,
                   [source] * len_gauge_id_list,
                   [ignore_columns] * len_gauge_id_list,
                   desc=f"正在加载{len_gauge_id_list}个流域的气象强迫和流量数据",
                   total=len_gauge_id_list,
                   leave=True,
                   ),
        keys=gauge_id_list,
        names=["gauge_id", "datetime"],
        axis=0,
    )


def load_basins_timeseries(gauge_id_list: Optional[List[str]] = None,
                           root_path: str = params.camels_root_path,
                           source: str = params.forcing_source,
                           ignore_columns: Optional[List[str]] = None,
                           multi_process: bool = False,
                           to_xarray: bool = False,
                           ) -> Union[DataFrame, Dataset]:
    """
    加载CAMELS数据集中所有流域的气象强迫和流量数据

    :param gauge_id_list: 流域ID列表，如果为None，则加载所有流域的ID
    :param root_path: CAMELS数据集根目录，默认为"camels_params"中的root_path
    :param source: 降水数据来源, 默认为"daymet", 可选值为"daymet"、“maurer"和”nldas"
    :param ignore_columns: 忽略的列名列表
    :param multi_process: 是否使用多进程
    :param to_xarray: 是否转换为xarray格式
    :return: 所有流域的气象强迫和流量数据
    """
    # 如果没有指定流域ID列表，则加载所有流域的ID
    if gauge_id_list is None:
        gauge_id_list, huc_02_list = get_gauge_id(root_path, True)
    else:
        huc_02_list = load_single_type_attributes("name", root_path).loc[gauge_id_list, "huc_02"].tolist()
    # 判断使用多线程还是多进程, 并加载所有流域的气象强迫和流量数据
    if multi_process:
        num_workers = cpu_count()
        # 先将流域ID列表和huc_02列表分成num_workers份
        gauge_id_lists = split_list(gauge_id_list, num_workers)
        huc_02_lists = split_list(huc_02_list, num_workers)
        # 使用多进程加载所有流域的气象强迫和流量数据
        with ProcessPoolExecutor() as executor:
            print(f"正在使用多个进程加载{len(gauge_id_list)}个流域的气象强迫和流量数据")
            result = pd.concat(
                executor.map(load_basins_timeseries_with_threads,
                             gauge_id_lists, huc_02_lists,
                             [root_path] * num_workers,
                             [source] * num_workers,
                             [ignore_columns] * num_workers,
                             ),
                axis=0,
            )
    else:
        result = load_basins_timeseries_with_threads(gauge_id_list, huc_02_list, root_path, source, ignore_columns)
    if to_xarray:
        result = result.to_xarray()
    return result


def load_timeseries(gauge_id: Optional[Union[str, List[str]]] = None,
                    root_path: str = params.camels_root_path,
                    source: str = params.forcing_source,
                    ignore_columns: Optional[List[str]] = None,
                    multi_process: bool = False,
                    to_xarray: bool = False,
                    ) -> Union[DataFrame, Dataset]:
    """
    加载CAMELS数据集中所有流域的气象强迫和流量数据

    :param gauge_id: 流域ID，可以是str(表示单个流域id)，也可以是List[str](表示多个流域id)
    :param root_path: CAMELS数据集根目录，默认为"camels_params"中的root_path
    :param source: 降水数据来源, 默认为"daymet", 可选值为"daymet"、“maurer"和”nldas"
    :param ignore_columns: 忽略的列名列表
    :param multi_process: 是否使用多进程, 仅对多个流域有效
    :param to_xarray: 是否转换为xarray格式, 仅对多个流域有效
    :return: 指定流域的气象强迫和流量数据
    """
    if gauge_id is None:
        return load_basins_timeseries(gauge_id_list=None,
                                      root_path=root_path,
                                      source=source,
                                      ignore_columns=ignore_columns,
                                      multi_process=multi_process,
                                      to_xarray=to_xarray)
    elif isinstance(gauge_id, str):
        return load_single_basin_timeseries(gauge_id,
                                            root_path=root_path,
                                            source=source,
                                            ignore_columns=ignore_columns)
    elif isinstance(gauge_id, list):
        return load_basins_timeseries(gauge_id_list=gauge_id,
                                      root_path=root_path,
                                      source=source,
                                      ignore_columns=ignore_columns,
                                      multi_process=multi_process,
                                      to_xarray=to_xarray)
